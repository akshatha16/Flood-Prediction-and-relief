

Webscarpe_flood_data.py is the script which extracts the flood data from the website http://india-water.gov.in and saves it in a .csv file.
If a particular area has rainfall above_normal level, then the repsetcive area and other information will be stored in the "above_normal.csv" file.
Similarly is there is severe flood in a particular area , it will be stored in "severe.csv" and extreme flood data in "extreme.csv".

This data can be later used, and a broadcast message can be sent to all the people in these effected areas and neighbouring areas, as a warning about the flood. 



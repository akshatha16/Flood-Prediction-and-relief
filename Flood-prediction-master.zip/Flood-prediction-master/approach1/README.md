
Machine learning approach of prediction of flood depending on previous year rainfall data.

An accuracy of 86.08 % is obtained just by taaking 3 features.
If more features like the topography type and land features are added then the accuracy can be improved.
We use logistic regression to train the model

We have predicted floods just for the state of kerala depending on the rainfall data. However this method can be used for prediction for any state of india, with the given data.

The input features used are the average rainfall in the month of marhc to may , the average rainfall in first 10 days of june and the inscrease in rainfall from the month of may to june, for all the years from 1901 to 2015

We used the months march, april, may and june to predict food in the later days of the month of june and july, as in keral the rainy season starts from the month of june. 
Depending on other states, other months will be used as the features.

I have commented the lines in the code for better reference
